package com.honey.loader;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class LoginActivity extends Activity {

    private EditText keyInput;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeUI();
    }

    private void initializeUI() {
        keyInput = findViewById(R.id.keyInput);
        Button pasteButton = findViewById(R.id.pasteButton);
        Button loginButton = findViewById(R.id.loginButton);

        pasteButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					handlePaste();
				}
			});

        loginButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					handleLogin();
				}
			});
    }

    private void handlePaste() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null && clipboard.hasPrimaryClip()) {
            try {
                CharSequence text = clipboard.getPrimaryClip().getItemAt(0).getText();
                if (text != null) {
                    keyInput.setText(text);
                }
            } catch (Exception e) {
                showToast("Error pasting text");
            }
        }
    }

    private void handleLogin() {
        String key = keyInput.getText().toString().trim();
        if (key.isEmpty()) {
            showToast("Please enter a key");
            return;
        }

        showProgressDialog();
        new KeyVerificationTask().execute(key);
    }

    private void showProgressDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Verifying key...");
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    private class KeyVerificationTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... keys) {
            HttpURLConnection connection = null;
            try {
                URL url = new URL("https://free.suhani.site/connect"); // Адрес API
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);

                // Устанавливаем заголовки
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Android GameLoader)");
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setRequestProperty("Accept", "application/json");

                // Данные запроса (замени UUID на реальный идентификатор устройства)
                String postData = "game=PUBG&user_key=" + URLEncoder.encode(keys[0], "UTF-8") +
					"&serial=" + URLEncoder.encode(getDeviceUUID(), "UTF-8");

                // Запись данных в запрос
                try (OutputStream os = connection.getOutputStream()) {
                    os.write(postData.getBytes(StandardCharsets.UTF_8));
                }

                // Читаем ответ
                int responseCode = connection.getResponseCode();
                if (responseCode == 200) {
                    return readStream(connection.getInputStream());
                } else {
                    return "Server error: " + responseCode;
                }
            } catch (Exception e) {
                return "Connection error: " + e.getMessage();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            Log.d("SERVER_RESPONSE", result);

            try {
                JSONObject jsonResponse = new JSONObject(result);
                boolean status = jsonResponse.getBoolean("status");

                if (status) {
                    String token = jsonResponse.getJSONObject("data").getString("token");
                    long rng = jsonResponse.getJSONObject("data").getLong("rng");

                    if (rng + 30 > System.currentTimeMillis() / 1000) {
                        String authString = "PUBG-" + keyInput.getText().toString().trim() + "-" +
							getDeviceUUID() + "-Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";
                        String calculatedAuth = md5(authString);

                        if (token.equals(calculatedAuth)) {
                            startMainActivity();
                        } else {
                            showToast("Invalid token");
                        }
                    } else {
                        showToast("Token expired");
                    }
                } else {
                    showToast("Invalid key: " + jsonResponse.getString("reason"));
                }
            } catch (Exception e) {
                showToast("Parsing error: " + e.getMessage());
            }
        }
    }

    private String readStream(java.io.InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }

    private String getDeviceUUID() {
        return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : digest) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void startMainActivity() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}

