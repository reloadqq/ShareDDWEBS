package com.honey.loader;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends Activity {

    private final String[] downloadUrls = {
        "https://www.mediafire.com/file/x5go2hwi5u899cd/ElytraX_Tw.apk/file?dkey=8ejfs4h4u8v&r=1998", 
        "https://download1085.mediafire.com/tvc4rpg8o2cgY1694LTUVb8ON5tGgynYxlgY7gzKeihFUsudNgWT1RDNIfQetr4hHSwG7SBfyQAIdU_bASJUe6AVTx2LPeh98kHOcYiWMvxDTVglZm6au83KqmYzFSj72tukL192axoZrEPP8aQDLG64nx_3bIQoH-QrvqTjAInF/8qcre6u0sjzjbdy/ElytraX+Vng.apk",
        "https://example.com/game3.apk",
        "https://example.com/game4.apk"
    };

    private final String[] packageNames = {
        "com.rekoo.pubgm",
        "com.vng.pubgmobile",
        "com.example.game3",
        "com.example.game4"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] buttonIds = {R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4};
        int[] progressBarIds = {R.id.downloadProgressBar1, R.id.downloadProgressBar2, R.id.downloadProgressBar3, R.id.downloadProgressBar4};
        int[] percentageTextIds = {R.id.downloadPercentageText1, R.id.downloadPercentageText2, R.id.downloadPercentageText3, R.id.downloadPercentageText4};

        for (int i = 0; i < buttonIds.length; i++) {
            Button button = findViewById(buttonIds[i]);
            final int index = i;
            final ProgressBar progressBar = findViewById(progressBarIds[i]);
            final TextView percentageText = findViewById(percentageTextIds[i]);

            updateButtonState(button, packageNames[index]);

            button.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						if (isAppInstalled(packageNames[index])) {
							startActivity(getPackageManager().getLaunchIntentForPackage(packageNames[index]));
						} else {
							downloadFile(downloadUrls[index], "game_" + (index + 1) + ".apk", progressBar, percentageText, index);
						}
					}
				});
        }
    }

    private void updateButtonState(Button button, String packageName) {
        if (isAppInstalled(packageName)) {
            button.setText("Play");
            button.setBackgroundColor(0xFF00FF00); // Green
        } else {
            button.setText("Install");
            button.setBackgroundColor(0xFFFF0000); // Red
        }
    }

    private void downloadFile(String url, String fileName, final ProgressBar progressBar, final TextView percentageText, final int index) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle("Install game");
            request.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                fileName
            );
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );

            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (manager != null) {
                long downloadId = manager.enqueue(request);
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show();

                // Track the download progress
                trackDownloadProgress(downloadId, progressBar, percentageText, index);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void trackDownloadProgress(long downloadId, final ProgressBar progressBar, final TextView percentageText, final int index) {
        final DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        if (manager == null) return;

        final DownloadManager.Query query = new DownloadManager.Query();
        query.setFilterById(downloadId);

        new Thread(new Runnable() {
				@Override
				public void run() {
					boolean isDownloadCompleted = false;
					while (!isDownloadCompleted) {
						android.database.Cursor cursor = manager.query(query);
						if (cursor != null) {
							cursor.moveToFirst();
							int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
							int bytesDownloaded = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
							int totalBytes = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));

							if (totalBytes > 0) {
								final int progress = (int) ((bytesDownloaded * 100L) / totalBytes);
								runOnUiThread(new Runnable() {
										@Override
										public void run() {
											progressBar.setProgress(progress);
											percentageText.setText(progress + "%");
										}
									});

								if (progress == 100) {
									String filePath = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
									File file = new File(Uri.parse(filePath).getPath());

									if (file.exists() && file.length() > 100000) {
										installApp(file);
										isDownloadCompleted = true;
									} else {
										Toast.makeText(MainActivity.this, "Download error: File is too small or corrupted", Toast.LENGTH_LONG).show();
										isDownloadCompleted = true;
									}
								}
							}

							if (status == DownloadManager.STATUS_FAILED) {
								Toast.makeText(MainActivity.this, "Download failed", Toast.LENGTH_LONG).show();
								isDownloadCompleted = true;
							}
							cursor.close();
						}
					}
				}
			}).start();
    }

    private void installApp(File file) {
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        if (checkSelfPermission(android.Manifest.permission.REQUEST_INSTALL_PACKAGES) == PackageManager.PERMISSION_GRANTED) {
            startActivity(intent);
        } else {
            requestPermissions(new String[]{android.Manifest.permission.REQUEST_INSTALL_PACKAGES}, 1);
        }
    }

    private boolean isAppInstalled(String packageName) {
        try {
            getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

